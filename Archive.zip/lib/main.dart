import 'package:flutter/material.dart';
import 'question.dart';
import 'answer.dart';

main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  int _questionIndex = 0;

  void answerQuestion() {
    if (_questionIndex == 2) {
      _questionIndex = -1;
    }
    else {
      setState(() {
        _questionIndex += 1;
      });
      print("Answer 1");
    }
  }

  final List<Map<String, Object>> questions = [
    {
      'questionText': 'What\'s your favourite color ? ',
      'answers': ['black', 'green', 'white']
    },
    {
      'questionText': 'What\'s your favourite Animal ? ',
      'answers': ['Rabbit', 'lion', 'tiger']
    },
  ];


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
            appBar: AppBar(
              title: Text("Quiz App"),
            ),
            body: Container(
              // width: double.infinity,
                child: Column(
                    children: <Widget> [
                Question(questions[_questionIndex]['questionText']),

                ...(questions[_questionIndex]['answers']) as List<String>.map((
                answer){return Answer(answerQuestion,answer);
                }).toList(),


    // Answer((answerQuestion), "Answer 1"),
    // Answer((answerQuestion), "Answer 1"),
    // Answer((answerQuestion), "Answer 1"),

    ],
    ),
    ),
    ),
    );
  }
}
